Map<String, String> socialMediaList = {
  "https://upload.wikimedia.org/wikipedia/en/thumb/0/04/Facebook_f_logo_%282021%29.svg/1200px-Facebook_f_logo_%282021%29.svg.png":
      "https://alaqsa.tech/",
  "https://i0.wp.com/aimanpsikologi.com/wp-content/uploads/2018/01/instagram-colourful-icon.png?ssl=1":
      "https://alaqsa.tech/",
  "https://cdn-icons-png.flaticon.com/512/124/124034.png?w=360":
      "https://wa.me/+601154225092",
  // "https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Telegram_2019_Logo.svg/800px-Telegram_2019_Logo.svg.png":
  //     "https://t.me/+966501510093",
  "https://static-00.iconduck.com/assets.00/gmail-icon-512x511-fih5xfbp.png":
      "mailto:taskforce.ppk@gmail.com",
  "https://media.tenor.com/zVNzIFTdYIEAAAAC/call.gif": "tel:+601154225092",
};
